from django.apps import AppConfig


class CommercialConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.commercial"
    verbose_name = "Gestion commerciale"
